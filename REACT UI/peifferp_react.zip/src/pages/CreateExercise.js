import React, {useState} from 'react';
import { useHistory } from 'react-router-dom';

function CreateExercise() {
    const history = useHistory()

    const [name, setName] = useState('')
    const [reps, setReps] = useState(0)
    const [weight, setWeight] = useState(0)
    const [unit, setUnit] = useState('lb')
    const [date, setDate] = useState('')

    const newExercise = async (e) => {
        e.preventDefault()
        const formInfo = {name, reps, weight, unit, date};
        const response = await fetch('/exercises', {
            method: 'POST',
            body: JSON.stringify(formInfo),
            headers: {
                'Content-Type': 'application/json',
            },
        });
        if (response.status === 201) {
            alert('Exercise successfully created!')
        } else {
            alert(`Failed to create exercise. Response code ${response.status}.`)
        };
        history.push("/");
    };

    return (
        <div>
            <h1>Create an Exercise</h1>
            <form>
                <div className="inputBox">
                    <label>Name of Exercise:
                        <input 
                            type="text"
                            value={name}
                            placeholder="e.g. Bench Press"
                            onChange={e => setName(e.target.value)}  />
                    </label>
                </div>
                
                <div className="inputBox">
                    <label>Number of Reps:
                        <input 
                            type="number"
                            value={reps}
                            placeholder="e.g. 10"
                            onChange={e => setReps(e.target.value)}  />
                    </label>
                </div>

                <div className="inputBox">
                    <label>Weight: 
                        <input 
                            type="number"
                            value={weight}
                            placeholder="e.g. 125"
                            onChange={e => setWeight(e.target.value)}  />
                    </label>
                </div>

                <div className="inputBox">
                    <label>Units: 
                        <select value={unit} onChange={e => setUnit(e.target.value)} > 
                            <option value="lb">lb</option>
                            <option value="kg">kg</option>
                        </select> 
                    </label>
                </div>

                <div className="inputBox">
                    <label>Date Logged: 
                        <input 
                            type="text"
                            value={date}
                            placeholder="Date MM-DD-YY"
                            onChange={e => setDate(e.target.value)}  />
                    </label>
                </div>

                <button onClick={newExercise}>Create Exercise</button>
            </form>
        </div>
    )
}

export default CreateExercise