import React, {useState} from 'react';
import { useHistory } from 'react-router-dom';

function EditExercise({exercisetoEdit}) {

    const history = useHistory()

    //define the states of the boxes
    const [name, setName] = useState(exercisetoEdit.name)
    const [reps, setReps] = useState(exercisetoEdit.reps)
    const [weight, setWeight] = useState(exercisetoEdit.weight)
    const [unit, setUnit] = useState(exercisetoEdit.unit)
    const [date, setDate] = useState(exercisetoEdit.date)

    //define the function to update the exercise
    const updateExercise = async (e) => {
        
        e.preventDefault()
        const modExercise = {name, reps, weight, unit, date}
        //fetch the PUT route from express server
        const response = await fetch(`/exercises/${exercisetoEdit._id}`, {
            method: 'PUT', 
            body: JSON.stringify(modExercise),
            headers: {
                'Content-Type': 'application/json',
            }
        })
        if (response.status === 200) {
            alert('Successfully updated exercise!')
        } else {
           alert(`Failed to update the exercise with ID ${exercisetoEdit._id}, status code ${response.status}`)
        }
        history.push('/')
    }

    return (
        <div>
            <h1>Update an Exercise</h1>
            <form>
                <div className="inputBox">
                    <label> Name of Exercise:
                        <input 
                        type="text"
                        value={name}
                        onChange={e => setName(e.target.value)}  />
                    </label>
                </div>

                <div className="inputBox">
                    <label>Number of Reps:
                        <input 
                        type="number"
                        value={reps}
                        onChange={e => setReps(e.target.value)}  />
                    </label>
                </div>

                <div className="inputBox">
                    <label>Weight:
                        <input 
                        type="number"
                        value={weight}
                        onChange={e => setWeight(e.target.value)}  />
                    </label>
                </div>

                <div className="inputBox">
                    <label>Units: 
                        <select value={unit} onChange={e => setUnit(e.target.value)} > 
                            <option value="lb">lb</option>
                            <option value="kg">kg</option>
                        </select> 
                    </label>
                </div>

                <div className="inputBox">
                    <label>Date Logged:
                        <input 
                        type="text"
                        value={date}
                        onChange={e => setDate(e.target.value)}  />
                    </label>
                </div>
                
                <button onClick={updateExercise}>Update</button>
            </form>
        </div>
    )
}

export default EditExercise