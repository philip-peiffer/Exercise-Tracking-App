import React from 'react';
import {TiPencil} from 'react-icons/ti'
import {VscTrash} from 'react-icons/vsc'

function TableRow({exercise, editExercise, deleteExercise}) {
    return (
        <tr>
            <td>{exercise.name}</td>
            <td>{exercise.reps}</td>
            <td>{exercise.weight}</td>
            <td>{exercise.unit}</td>
            <td>{exercise.date}</td>
            <td className="icons"><TiPencil onClick={() => editExercise(exercise)}/> </td>
            <td className="icons"><VscTrash onClick={() => deleteExercise(exercise._id)}/> </td> 
        </tr>
    )
}

export default TableRow