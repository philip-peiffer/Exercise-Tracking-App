import React from 'react';

function TableHeader() {
    return (
        <tr>
            <th>Name</th>
            <th>Reps</th>
            <th>Weight</th>
            <th>Units</th>
            <th>Date</th>
        </tr>
    )
}

export default TableHeader